const Tab1 = () => {
  return <div>This is Tab 1</div>;
};
export default Tab1;
