const Tab3 = () => {
  return <div>This is Tab 3</div>;
};
export default Tab3;
